# !/usr/bin/.venv python
from brain_games.scripts. calc import game_flow

def main():
    user_name = welcome_user()
    game_flow(CNT_ATTEMPTS, game, user_name)


if __name__ == '__main__':
    main()
